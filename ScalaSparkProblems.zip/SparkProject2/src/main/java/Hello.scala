object Hello extends App{

  override def main(args:Array[String]) : Unit = {
    println("Krithika, It's done dear")
  }
}
